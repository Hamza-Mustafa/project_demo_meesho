//
//  UIStackView+Extension.swift
//  project_demo_meesho
//
//  Created by Hamza Mustafa on 26/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import Foundation

import UIKit

extension UIStackView {
    func removeAllArrangedSubviews() {
        let subviews = self.arrangedSubviews
        subviews.forEach( { $0.removeFromSuperview()})
    }
}
