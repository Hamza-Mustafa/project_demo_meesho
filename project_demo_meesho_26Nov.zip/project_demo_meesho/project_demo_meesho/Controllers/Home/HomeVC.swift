//
//  HomeVC.swift
//  project_demo_meesho
//
//  Created by Hamza Mustafa on 25/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    override func viewWillAppear(_ animated: Bool) {
        if let nav = self.navigationController as? LargeNavigationController {
            nav.title = "Home"
            nav.showTitle()
            let backButton = LargeNavigationController.ButtonItem(image: UIImage(named: "backold")) {
                //self.navigationController?.dismiss(animated: true, completion: nil)
                print("back")
            }
                        
            let heartButton = LargeNavigationController.ButtonItem(image: UIImage(named: "heart")) {
                print("heart button pressed")
                //let vc = ESchedulerVC.instantiate(fromStoryboard: .BottomNav)
                //self.navigationController?.pushViewController(vc, animated: true)
            }

            let cartButton = LargeNavigationController.ButtonItem(image: UIImage(named: "shopping-cart")) {
                print("cart button pressed")
            }
            nav.addRightBarButtons(buttons: [heartButton, cartButton])
            nav.addLeftBarButtons(buttons: [backButton])
            nav.showTitle()
            nav.setup()
        }
    }
}
