//
//  OnBoardingVC.swift
//  project_demo_meesho
//
//  Created by Qaim Raza on 22/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class OnBoardingVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    @IBAction func continueBtPressed(_ sender: UIButton) {
//        if let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "MobileNumberVC") as? MobileNumberVC {
//            self.navigationController?.pushViewController(secondVC, animated: true)
//        }
        
        guard let window = UIApplication.shared.keyWindowInConnectedScenes else {return}
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let TabbarController = mainStoryboard.instantiateViewController(withIdentifier: "TabBarId") as! UITabBarController
        UIView.transition(with: window, duration: 0.3, options: .transitionCrossDissolve, animations: {}, completion: nil )
        UIApplication.shared.keyWindowInConnectedScenes?.rootViewController = TabbarController
    }
}
