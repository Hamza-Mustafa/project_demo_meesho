//
//  LargeNavigationController.swift
//  project_demo_meesho
//
//  Created by Hamza Mustafa on 25/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class LargeNavigationController: UINavigationController {
    
    struct ButtonItem {
        var image: UIImage?
        var onPress: (() -> Void)
    }
    
    private let topView = UIView()
    private let mainTitle = UILabel()
    private let rightStackView = UIStackView()
    private let leftStackView = UIStackView()
    private let logoButton = UIButton(type: .custom)
    private let searchTextField = UITextField()
    
    private var logoButtonisHidden = true
    
    override var title: String? {
        didSet{
            self.mainTitle.text = title
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarHidden(true, animated: false)
        
        // top View
        topView.translatesAutoresizingMaskIntoConstraints = false
        topView.backgroundColor = UIColor.blue
        self.view.addSubview(topView)
        NSLayoutConstraint.activate([
            topView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            topView.heightAnchor.constraint(greaterThanOrEqualToConstant: 80.0),
            topView.topAnchor.constraint(equalTo: self.view.topAnchor)
        ])
        
        // back button
        logoButton.setImage(UIImage(named: "backold"), for: .normal)
        logoButton.translatesAutoresizingMaskIntoConstraints = false
        logoButton.addTarget(self, action: #selector(logoButtonTapped), for: .touchUpInside)
        topView.addSubview(logoButton)
        
        NSLayoutConstraint.activate([
            logoButton.widthAnchor.constraint(equalToConstant: 35.0),
            logoButton.heightAnchor.constraint(equalToConstant: 25.0),
            logoButton.topAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.topAnchor , constant: 5.0),
            logoButton.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 5.0)
        ])
        logoButton.isHidden = true
        
        //add search text field
        searchTextField.textColor = .white
        searchTextField.translatesAutoresizingMaskIntoConstraints = false
        searchTextField.backgroundColor = UIColor.white
        searchTextField.tintColor = UIColor.lightGray
        searchTextField.setTextfieldImageLeft(#imageLiteral(resourceName: "search"))
        topView.addSubview(searchTextField)
        NSLayoutConstraint.activate([
            searchTextField.heightAnchor.constraint(equalToConstant: 35.0),
            searchTextField.topAnchor.constraint(equalTo: logoButton.bottomAnchor,constant: 10.0),
            searchTextField.leadingAnchor.constraint(equalTo: topView.leadingAnchor,constant: 10.0),
            searchTextField.trailingAnchor.constraint(equalTo: topView.trailingAnchor,constant: -10.0),
            searchTextField.bottomAnchor.constraint(equalTo: topView.bottomAnchor,constant: -10.0)
        ])
        
        // add stackview for right button
        rightStackView.axis = .horizontal
        rightStackView.alignment = .center
        rightStackView.spacing = 0.0
        rightStackView.backgroundColor = UIColor.white
        
        rightStackView.translatesAutoresizingMaskIntoConstraints = false
        topView.addSubview(rightStackView)
        NSLayoutConstraint.activate([
            rightStackView.topAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.topAnchor , constant: 10.0 ),
            rightStackView.trailingAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.trailingAnchor , constant: -10.0)
        ])
        
        // add stackView for left buttons
        leftStackView.axis = .horizontal
        leftStackView.alignment = .center
        leftStackView.spacing = 0.0
        leftStackView.backgroundColor = UIColor.white
        
        leftStackView.translatesAutoresizingMaskIntoConstraints = false
        topView.addSubview(leftStackView)
        NSLayoutConstraint.activate([
            leftStackView.topAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.topAnchor, constant: 10.0),
            leftStackView.leadingAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.leadingAnchor, constant: 10.0)
        ])
        
        topView.setNeedsLayout()
        topView.layoutIfNeeded()
    }
    
    override func show(_ vc: UIViewController, sender: Any?) {
        // show backbutton if more than one vcs are on stack
        if self.viewControllers.count == 1 {
            self.logoButton.isHidden = false
        }
        
        // remove all right buttons
        self.rightStackView.removeAllArrangedSubviews()
        self.leftStackView.removeAllArrangedSubviews()
        //self.searchTextField.isHidden = true
        super.show(vc, sender: sender)
    }
    
    override func popViewController(animated: Bool) -> UIViewController? {
        self.rightStackView.removeAllArrangedSubviews()
        self.leftStackView.removeAllArrangedSubviews()
        //self.rightTitleLabel.isHidden = true
        
        if self.viewControllers.count == 2 {
            self.logoButton.isHidden = true
        }

        return super.popViewController(animated: animated)
    }
    
    private func addRightBarButton(with image: UIImage?, _ onPress:@escaping ()->Void) {
        let button = UIButton(type: .custom)
        button.setImage(image, for: .normal)
        button.addAction(action:onPress)
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 35.0),
            button.heightAnchor.constraint(equalToConstant: 25.0)
        ])
        rightStackView.addArrangedSubview(button)
    }
    
    func addRightBarButtons(buttons: [ButtonItem]) {
        // remove previously added buttons
        self.rightStackView.removeAllArrangedSubviews()
        
        buttons.forEach { (item) in
            self.addRightBarButton(with: item.image, item.onPress)
        }
    }
    
    private func addLeftBarButton(with image: UIImage?, _ onPress:@escaping ()->Void) {
        let button = UIButton(type: .custom)
        button.setImage(image, for: .normal)
        button.addAction(action: onPress)
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 35.0),
            button.heightAnchor.constraint(equalToConstant: 25.0)
        ])
        leftStackView.addArrangedSubview(button)
    }
    
    func addLeftBarButtons(buttons: [ButtonItem]) {
        // remove previously added buttons
        self.leftStackView.removeAllArrangedSubviews()
        
        buttons.forEach { (item) in
            self.addLeftBarButton(with: item.image, item.onPress)
        }
    }
    
    func hideTitle() {
        self.mainTitle.removeFromSuperview()
    }
    
    func hideBackButton() {
        self.logoButtonisHidden = true
    }
    
    func showBackButton() {
        self.logoButtonisHidden = false
    }
    
    func showTitle() {
        mainTitle.translatesAutoresizingMaskIntoConstraints = false
        mainTitle.backgroundColor = UIColor.white
        mainTitle.textAlignment = .center
        topView.addSubview(mainTitle)
        NSLayoutConstraint.activate([
            mainTitle.topAnchor.constraint(equalTo: topView.safeAreaLayoutGuide.topAnchor, constant: 10.0),
            mainTitle.leadingAnchor.constraint(equalTo: leftStackView.trailingAnchor, constant: 5.0),
            mainTitle.trailingAnchor.constraint(equalTo: rightStackView.leadingAnchor, constant: -5.0),
            mainTitle.bottomAnchor.constraint(equalTo: searchTextField.topAnchor, constant: -5)
        ])
    }
    
    func updateTitleText(text: String) {
        self.title = text
    }
    
    func hideBar() {
        self.topView.isHidden = true
    }
    
    func showBar() {
        self.topView.isHidden = false
    }
    
    func setup() {
        if viewControllers.count > 1 {
            self.logoButton.isHidden = logoButtonisHidden
        }
        else {
            self.logoButton.isHidden = true
        }
    }
    
    
    @objc func logoButtonTapped() {
        print("tapped")
    }
}
