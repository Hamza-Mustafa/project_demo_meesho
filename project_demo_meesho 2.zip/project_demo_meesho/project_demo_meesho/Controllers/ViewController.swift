//
//  ViewController.swift
//  project_demo_meesho
//
//  Created by Qaim Raza on 05/10/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigationBarItems()
    }
    
    private func setUpNavigationBarItems(){
        let titleImageView = UIImageView(image: #imageLiteral(resourceName: "logo"))
        titleImageView.frame = CGRect(x: 0, y: 0, width: 34, height: 34)
        titleImageView.contentMode = .scaleAspectFit
        navigationItem.titleView = titleImageView
    }

    @objc func addTapped(){
        print("add tapped!")
    }
}
