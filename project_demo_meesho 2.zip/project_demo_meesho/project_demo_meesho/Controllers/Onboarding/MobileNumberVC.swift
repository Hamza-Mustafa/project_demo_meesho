//
//  MobileNumberVC.swift
//  project_demo_meesho
//
//  Created by Qaim Raza on 23/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit
import FlagPhoneNumber

class MobileNumberVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var phoneNumberTxt: FPNTextField!
    var listController: FPNCountryListViewController = FPNCountryListViewController(style: .grouped)
    var regexCheck : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupFlagPicker()
        setupIcons()
    }
    
    func setupIcons() {
        phoneNumberTxt.tintColor = UIColor.lightGray
        phoneNumberTxt.setTextfieldImage(#imageLiteral(resourceName: "down-arrow"))
    }
    
    func setupFlagPicker() {
        Bundle.FlagIcons = Bundle(for: MobileNumberVC.self)
        listController.setup(repository: phoneNumberTxt.countryRepository)
        listController.didSelect = { [weak self] country in
            self?.phoneNumberTxt.setFlag(countryCode: country.code)
        }
        phoneNumberTxt.delegate = self
        // You can change the chosen flag then set the phone number
        phoneNumberTxt.setFlag(key: .PK)
        phoneNumberTxt.setFlag(countryCode: .PK)
        phoneNumberTxt.borderStyle = .roundedRect
        phoneNumberTxt.pickerView.showPhoneNumbers = false
        phoneNumberTxt.displayMode = .picker // .picker by default
        // Custom the size/edgeInsets of the flag button
        phoneNumberTxt.flagButtonSize = CGSize(width: 35, height: 35)
        phoneNumberTxt.flagButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        phoneNumberTxt.hasPhoneNumberExample = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }

    @objc func dismissCountries() {
        listController.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func verifyOTP(_ sender: UIButton) {
        let error = validateErrors()
        if error != nil {
            Validation.alertAction(titletext: "Oops!", msgText: error!, vc: self)
        }
        else {
            if let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "OtpVC") as? OtpVC {
                self.navigationController?.pushViewController(secondVC, animated: true)
            }
        }
    }

    func validateErrors() -> String? {
        if let phoneNumber = phoneNumberTxt.text {
            if phoneNumber.isEmpty {
                return "Please write down mobile number"
             }
         }
        
        if regexCheck == false {
            return "Phone number format is wrong"
        }
         return nil
     }
}

extension MobileNumberVC: FPNTextFieldDelegate {

    func fpnDidValidatePhoneNumber(textField: FPNTextField, isValid: Bool) {
        print(
            isValid,
            textField.getFormattedPhoneNumber(format: .E164) ?? "E164: nil",
            textField.getFormattedPhoneNumber(format: .International) ?? "International: nil",
            textField.getFormattedPhoneNumber(format: .National) ?? "National: nil",
            textField.getFormattedPhoneNumber(format: .RFC3966) ?? "RFC3966: nil",
            textField.getRawPhoneNumber() ?? "Raw: nil"
        )
        
        if isValid == true {
            regexCheck = true
        }
    }

    func fpnDidSelectCountry(name: String, dialCode: String, code: String) {
        print(name, dialCode, code)
    }
    
    func fpnDisplayCountryList() {}
}
