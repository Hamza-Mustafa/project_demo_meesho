//
//  OtpVC.swift
//  project_demo_meesho
//
//  Created by Qaim Raza on 21/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class OtpVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    @IBAction func verifyBtPressed(_ sender: UIButton) {
        guard let window = UIApplication.shared.keyWindowInConnectedScenes else {return}
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let TabbarController = mainStoryboard.instantiateViewController(withIdentifier: "TabBarId") as! UITabBarController
        UIView.transition(with: window, duration: 0.3, options: .transitionCrossDissolve, animations: {}, completion: nil )
        UIApplication.shared.keyWindowInConnectedScenes?.rootViewController = TabbarController
    }
}
