//
//  LargeNavigationController.swift
//  project_demo_meesho
//
//  Created by Hamza Mustafa on 25/11/2020.
//  Copyright © 2020 Qaim Raza. All rights reserved.
//

import UIKit

class LargeNavigationController: UINavigationController {
    
    private let topView = UIView()
    private let mainTitle = UILabel()
    private let rightStackView = UIStackView()
    private let leftStackView = UIStackView()
    private let LogoButton = UIButton(type: .custom)
    private let searchTextField = UITextField()
    
    override var title: String? {
        didSet{
            self.mainTitle.text = title
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarHidden(true, animated: false)
        
        // top View
        topView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(topView)
        NSLayoutConstraint.activate([
            topView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            topView.heightAnchor.constraint(greaterThanOrEqualToConstant: 60.0),
            topView.topAnchor.constraint(equalTo: self.view.topAnchor)
        ])
        
        //back button
        LogoButton.setImage(UIImage(named: "back"), for: .normal)
        LogoButton.translatesAutoresizingMaskIntoConstraints = false
        LogoButton.addTarget(self, action: #selector(logoButtonTapped), for: .touchUpInside)
        topView.addSubview(LogoButton)
        
        NSLayoutConstraint.activate([
            LogoButton.widthAnchor.constraint(equalToConstant: 35.0),
            LogoButton.heightAnchor.constraint(equalToConstant: 25.0),
            
            
            
        ])

    }
    
    
    @objc func logoButtonTapped() {
        
    }
}
